"""
Multi-Source News Aggregator Application
Compatible with Python 3.14+
"""

import requests
import json
import hashlib
from datetime import datetime
from typing import List, Dict
import time
import os
import xml.etree.ElementTree as ET
from config import *

class NewsAggregator:
    """Main class for news aggregation functionality"""
    
    def __init__(self):
        """Initialize the news aggregator"""
        self.articles = []
        self.seen_articles = set()
        self.api_key = NEWS_API_KEY
        self.setup_directories()
        
    def setup_directories(self):
        """Create necessary directories"""
        if not os.path.exists("saved_articles"):
            os.makedirs("saved_articles")
            
    def generate_article_id(self, title: str, source: str, date: str) -> str:
        """Generate unique ID for article to avoid duplicates"""
        unique_string = f"{title}{source}{date}"
        return hashlib.md5(unique_string.encode()).hexdigest()
    
    def fetch_news_from_api(self, category: str = None, keyword: str = None) -> List[Dict]:
        """Fetch news from NewsAPI"""
        articles = []
        
        if self.api_key == "YOUR_API_KEY_HERE":
            return articles
            
        try:
            if keyword:
                url = f"{NEWS_API_BASE_URL}/everything"
                params = {
                    "q": keyword,
                    "apiKey": self.api_key,
                    "language": "en",
                    "pageSize": 15,
                    "sortBy": "relevancy"
                }
            else:
                url = f"{NEWS_API_BASE_URL}/top-headlines"
                params = {
                    "category": category if category else "general",
                    "apiKey": self.api_key,
                    "language": "en",
                    "country": "us",
                    "pageSize": 15
                }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data["status"] == "ok" and data["articles"]:
                for item in data["articles"]:
                    if item["title"] and item["title"] != "[Removed]":
                        article_id = self.generate_article_id(
                            item["title"], 
                            item["source"]["name"],
                            item["publishedAt"]
                        )
                        
                        if article_id not in self.seen_articles:
                            self.seen_articles.add(article_id)
                            articles.append({
                                "id": article_id,
                                "title": item["title"],
                                "source": item["source"]["name"],
                                "date": item["publishedAt"][:10] if item["publishedAt"] else "Unknown",
                                "description": (item["description"] or "No description available")[:200],
                                "url": item["url"],
                                "category": category if category else "general"
                            })
                            
        except Exception as e:
            print(f"⚠️ API Error: {e}")
            
        return articles
    
    def parse_rss_feed(self, feed_url: str) -> List[Dict]:
        """Parse RSS feed using XML ElementTree (no feedparser needed)"""
        articles = []
        
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(feed_url, timeout=10, headers=headers)
            response.raise_for_status()
            
            # Parse XML
            root = ET.fromstring(response.content)
            
            # Find all items in the RSS feed
            # RSS namespace handling
            ns = {'default': 'http://www.w3.org/2005/Atom'}
            
            # Try different possible paths for items
            items = root.findall('.//item') or root.findall('.//entry')
            
            for item in items[:10]:  # Limit to 10 per feed
                # Extract title
                title_elem = item.find('title')
                title = title_elem.text if title_elem is not None else "No title"
                
                # Extract description/summary
                desc_elem = item.find('description') or item.find('summary')
                description = desc_elem.text if desc_elem is not None else "No description"
                if description:
                    description = description[:200]
                
                # Extract link
                link_elem = item.find('link')
                if link_elem is not None:
                    if 'href' in link_elem.attrib:
                        link = link_elem.attrib['href']
                    else:
                        link = link_elem.text or '#'
                else:
                    link = '#'
                
                # Extract date
                date_elem = item.find('pubDate') or item.find('published')
                date = date_elem.text[:10] if date_elem is not None else datetime.now().strftime("%Y-%m-%d")
                
                # Extract source name from feed URL
                source_name = feed_url.split('//')[-1].split('/')[0].replace('www.', '')
                
                article_id = self.generate_article_id(title, source_name, date)
                
                if article_id not in self.seen_articles:
                    self.seen_articles.add(article_id)
                    articles.append({
                        "id": article_id,
                        "title": title,
                        "source": source_name,
                        "date": date,
                        "description": description,
                        "url": link,
                        "category": "general"
                    })
                    
        except ET.ParseError as e:
            print(f"⚠️ XML Parse Error for {feed_url}: {e}")
        except Exception as e:
            print(f"⚠️ Error fetching RSS {feed_url}: {e}")
            
        return articles
    
    def fetch_news_from_rss(self, category: str = None, keyword: str = None) -> List[Dict]:
        """Fetch news from RSS feeds"""
        articles = []
        
        # Alternative RSS feeds that work well
        alternative_feeds = {
            "technology": [
                "https://feeds.feedburner.com/TechCrunch",
                "https://www.theverge.com/rss/index.xml",
                "https://www.wired.com/feed/rss"
            ],
            "sports": [
                "https://www.espn.com/espn/rss/news",
                "https://rss.nytimes.com/services/xml/rss/nyt/Sports.xml"
            ],
            "business": [
                "https://www.wsj.com/xml/rss/3_7085.xml",
                "https://feeds.bloomberg.com/markets/news.rss"
            ],
            "entertainment": [
                "https://variety.com/feed/",
                "https://www.eonline.com/news/feed"
            ]
        }
        
        feeds_to_fetch = []
        if category and category in alternative_feeds:
            feeds_to_fetch = alternative_feeds[category]
        else:
            # Fetch all feeds
            for feeds in alternative_feeds.values():
                feeds_to_fetch.extend(feeds)
        
        for feed_url in feeds_to_fetch[:4]:  # Limit to 4 feeds
            print(f"   📡 Reading: {feed_url.split('/')[2]}...")
            feed_articles = self.parse_rss_feed(feed_url)
            
            # Apply keyword filter if needed
            if keyword:
                feed_articles = [
                    a for a in feed_articles 
                    if keyword.lower() in a['title'].lower() or keyword.lower() in a['description'].lower()
                ]
            
            # Add category
            for article in feed_articles:
                article['category'] = category if category else "general"
            
            articles.extend(feed_articles)
            time.sleep(0.5)  # Be polite to servers
            
        return articles
    
    def get_news(self, category: str = None, keyword: str = None, use_api: bool = True) -> List[Dict]:
        """Get news from multiple sources"""
        all_articles = []
        
        # Reset seen articles
        self.seen_articles = set()
        
        # Fetch from NewsAPI
        if use_api and self.api_key != "YOUR_API_KEY_HERE":
            print("📡 Fetching from NewsAPI...")
            api_articles = self.fetch_news_from_api(category, keyword)
            all_articles.extend(api_articles)
            print(f"✅ Found {len(api_articles)} articles from NewsAPI")
        elif use_api and self.api_key == "YOUR_API_KEY_HERE":
            print("⚠️ NewsAPI key not configured. Using RSS feeds only...")
        
        # Fetch from RSS feeds
        print("📰 Fetching from RSS feeds...")
        rss_articles = self.fetch_news_from_rss(category, keyword)
        all_articles.extend(rss_articles)
        print(f"✅ Found {len(rss_articles)} articles from RSS feeds")
        
        # Sort by date (newest first)
        all_articles.sort(key=lambda x: x['date'], reverse=True)
        
        self.articles = all_articles
        return self.articles
    
    def display_news(self, articles: List[Dict], page_size: int = 5):
        """Display news articles in a formatted way"""
        if not articles:
            print("\n❌ No articles found. Please try a different category or keyword.\n")
            input("Press Enter to continue...")
            return
        
        total_pages = (len(articles) + page_size - 1) // page_size
        current_page = 0
        
        while current_page < total_pages:
            start_idx = current_page * page_size
            end_idx = min(start_idx + page_size, len(articles))
            
            os.system('cls' if os.name == 'nt' else 'clear')
            
            print("\n" + "="*80)
            print(f"📰 NEWS ARTICLES - Page {current_page + 1} of {total_pages}")
            print("="*80)
            
            for idx, article in enumerate(articles[start_idx:end_idx], start=start_idx + 1):
                print(f"\n{idx}. 📌 {article['title']}")
                print(f"   📍 Source: {article['source']}")
                print(f"   📅 Date: {article['date']}")
                print(f"   📝 {article['description'][:150]}...")
                print(f"   🔗 URL: {article['url']}")
                print("-"*80)
            
            print(f"\n📊 Showing {start_idx + 1} to {end_idx} of {len(articles)} articles")
            
            if current_page + 1 < total_pages:
                choice = input("\n📖 Next page (N) | 💾 Save article (S) | 🔙 Back to menu (B): ").upper()
                
                if choice == 'N':
                    current_page += 1
                elif choice == 'S':
                    self.save_article_menu(articles[start_idx:end_idx])
                elif choice == 'B':
                    break
            else:
                input("\n✅ End of results. Press Enter to continue...")
                break
    
    def save_article_menu(self, articles: List[Dict]):
        """Display menu to save articles"""
        if not articles:
            print("No articles to save.")
            return
        
        print("\n💾 SAVE ARTICLE")
        print("-"*40)
        
        for idx, article in enumerate(articles, 1):
            print(f"{idx}. {article['title'][:60]}...")
        
        try:
            choice = input("\nEnter article number to save (or 0 to cancel): ")
            if choice == "0":
                return
            
            article_idx = int(choice) - 1
            if 0 <= article_idx < len(articles):
                self.save_article_to_file(articles[article_idx])
            else:
                print("❌ Invalid article number!")
        except ValueError:
            print("❌ Invalid input!")
    
    def save_article_to_file(self, article: Dict):
        """Save article to JSON file"""
        filename = SAVED_ARTICLES_FILE
        
        existing_articles = []
        if os.path.exists(filename):
            try:
                with open(filename, 'r', encoding='utf-8') as f:
                    existing_articles = json.load(f)
            except:
                existing_articles = []
        
        if any(a['id'] == article['id'] for a in existing_articles):
            print("⚠️ Article already saved!")
            return
        
        article['saved_at'] = datetime.now().isoformat()
        existing_articles.append(article)
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(existing_articles, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Article saved to {filename}")
        time.sleep(1)
    
    def view_saved_articles(self):
        """Display saved articles"""
        filename = SAVED_ARTICLES_FILE
        
        if not os.path.exists(filename):
            print("\n📭 No saved articles found.\n")
            input("Press Enter to continue...")
            return
        
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                saved_articles = json.load(f)
            
            if not saved_articles:
                print("\n📭 No saved articles found.\n")
                input("Press Enter to continue...")
                return
            
            print("\n" + "="*80)
            print("📚 SAVED ARTICLES")
            print("="*80)
            
            for idx, article in enumerate(saved_articles, 1):
                print(f"\n{idx}. 📌 {article['title']}")
                print(f"   📍 Source: {article['source']}")
                print(f"   📅 Date: {article['date']}")
                print(f"   💾 Saved: {article.get('saved_at', 'Unknown')}")
                print("-"*80)
            
            print(f"\n📊 Total saved articles: {len(saved_articles)}")
            input("\nPress Enter to continue...")
            
        except Exception as e:
            print(f"⚠️ Error reading saved articles: {e}")
    
    def search_news(self):
        """Search news by keyword"""
        print("\n🔍 SEARCH NEWS")
        print("-"*40)
        keyword = input("Enter search keyword: ").strip()
        
        if not keyword:
            print("❌ Please enter a keyword!")
            time.sleep(1)
            return
        
        print(f"\n🔎 Searching for '{keyword}'...")
        articles = self.get_news(keyword=keyword)
        
        if articles:
            self.display_news(articles)
        else:
            print(f"\n❌ No articles found for '{keyword}'")
            input("Press Enter to continue...")
    
    def filter_by_category(self):
        """Filter news by category"""
        print("\n📂 CATEGORIES")
        print("-"*40)
        
        for key, value in CATEGORIES.items():
            print(f"{key}. {value.capitalize()}")
        
        choice = input("\nSelect category (1-4): ").strip()
        
        if choice in CATEGORIES:
            category = CATEGORIES[choice]
            print(f"\n📰 Fetching {category} news...")
            articles = self.get_news(category=category)
            
            if articles:
                self.display_news(articles)
            else:
                print(f"\n❌ No articles found for {category}")
                input("Press Enter to continue...")
        else:
            print("❌ Invalid category selection!")
            time.sleep(1)
    
    def view_latest_news(self):
        """View latest news from all sources"""
        print("\n📰 FETCHING LATEST NEWS...")
        print("This might take a few moments...\n")
        
        articles = self.get_news()
        
        if articles:
            self.display_news(articles)
        else:
            print("\n❌ No articles found. Please check your internet connection.\n")
            input("Press Enter to continue...")
    
    def export_to_csv(self):
        """Export current articles to CSV file"""
        if not self.articles:
            print("\n❌ No articles to export. Please fetch news first.\n")
            input("Press Enter to continue...")
            return
        
        import csv
        
        filename = f"exported_news_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['title', 'source', 'date', 'description', 'url', 'category']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for article in self.articles:
                    writer.writerow({k: article.get(k, '') for k in fieldnames})
            
            print(f"\n✅ Articles exported to {filename}")
            input("\nPress Enter to continue...")
            
        except Exception as e:
            print(f"\n❌ Error exporting articles: {e}")
            input("Press Enter to continue...")
    
    def show_menu(self):
        """Display main menu"""
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            
            print("\n" + "="*60)
            print("   📰 MULTI-SOURCE NEWS AGGREGATOR")
            print("="*60)
            print("\n📋 MAIN MENU")
            print("-"*40)
            print("1. 📰 View Latest News")
            print("2. 🔍 Search News")
            print("3. 📂 Filter by Category")
            print("4. 📚 View Saved Articles")
            print("5. 💾 Export All Articles")
            print("6. 🚪 Exit")
            print("-"*40)
            
            choice = input("\n👉 Enter your choice (1-6): ").strip()
            
            if choice == "1":
                self.view_latest_news()
            elif choice == "2":
                self.search_news()
            elif choice == "3":
                self.filter_by_category()
            elif choice == "4":
                self.view_saved_articles()
            elif choice == "5":
                self.export_to_csv()
            elif choice == "6":
                print("\n👋 Thank you for using News Aggregator. Goodbye!\n")
                break
            else:
                print("❌ Invalid choice! Please try again.")
                time.sleep(1)

def main():
    """Main entry point"""
    try:
        if NEWS_API_KEY == "YOUR_API_KEY_HERE":
            print("\n⚠️ WARNING: NewsAPI key not configured!")
            print("Get your free API key from https://newsapi.org/")
            print("Add it to config.py file for better results")
            print("\nContinuing with RSS feeds only...\n")
            time.sleep(2)
        
        app = NewsAggregator()
        app.show_menu()
        
    except KeyboardInterrupt:
        print("\n\n👋 Application closed. Goodbye!\n")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        print("Please restart the application.\n")

if __name__ == "__main__":
    main()