# NewsAPI configuration (Get your free API key from https://newsapi.org/)
NEWS_API_KEY = "YOUR_API_KEY_HERE"  # Replace with your actual API key

# API endpoints
NEWS_API_BASE_URL = "https://newsapi.org/v2"

# Categories supported
CATEGORIES = {
    "1": "technology",
    "2": "sports", 
    "3": "business",
    "4": "entertainment"
}

# RSS Feeds (alternative sources)
RSS_FEEDS = {
    "technology": [
        "http://feeds.feedburner.com/TechCrunch",
        "https://www.wired.com/feed/rss"
    ],
    "sports": [
        "http://www.espn.com/espn/rss/news",
        "https://feeds.bbci.co.uk/sport/rss.xml"
    ],
    "business": [
        "http://feeds.bloomberg.com/markets/news.rss",
        "https://www.wsj.com/xml/rss/3_7085.xml"
    ],
    "entertainment": [
        "http://variety.com/feed/",
        "https://www.hollywoodreporter.com/feed"
    ]
}

# File paths
SAVED_ARTICLES_FILE = "saved_articles/news.json"